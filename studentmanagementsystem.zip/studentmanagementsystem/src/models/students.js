const mongoose = require("mongoose");
const validator = require("validator");

const studentSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        trim: true,
        minlength: 3
    },
    email: {
        type: String,
        required: true,
        trim: true,
        unique: [true, "This email already exists"],
        validate(value) {
            if (!validator.isEmail(value)) {
                throw new Error("Email is invalid");
            }
        }
    },
    phone: {
        type: Number,
        required: true,
        min: 1000000000 // Ensure phone number is 10 digits
    },
    address: {
        type: String,
        required: true,
        trim: true
    },
    image: {
        type: String, // URL of the image
        required: false
    }
});

const Student = mongoose.model("Student", studentSchema);

module.exports = Student;
