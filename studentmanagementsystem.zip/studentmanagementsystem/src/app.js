const express = require("express");
const app = express();
require('./db/conn');
const Student = require('./models/students');
const port = 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.set("view engine", "ejs");

app.get("/", (req, res) => {
    res.render("index.ejs");
});

app.post("/student", async (req, res) => {
    try {
        const user = new Student(req.body);
        await user.save();
        res.status(201).render("success.ejs");
    } catch (e) {
        res.status(400).send(e);
    }
});

app.get("/register", (req, res) => {
    res.render("register.ejs");
});

app.get("/students", async (req, res) => {
    try {
        const students = await Student.find();
        res.render("table.ejs", { students });
    } catch (e) {
        res.status(500).send("Error fetching students");
    }
});

app.get("/students/edit/:id", async (req, res) => {
    try {
        const student = await Student.findById(req.params.id);
        if (!student) {
            return res.status(404).send("Student not found");
        }
        res.render("edit.ejs", { student });
    } catch (e) {
        res.status(500).send("Error fetching student");
    }
});

app.post("/students/edit/:id", async (req, res) => {
    try {
        const student = await Student.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!student) {
            return res.status(404).send("Student not found");
        }
        res.redirect("/students");
    } catch (e) {
        res.status(400).send("Error updating student");
    }
});

app.get("/students/view/:id", async (req, res) => {
    try {
        const student = await Student.findById(req.params.id);
        if (!student) {
            return res.status(404).send("Student not found");
        }
        res.render("view.ejs", { student });
    } catch (e) {
        res.status(500).send("Error fetching student details");
    }
});

app.get("/students/delete/:id", async (req, res) => {
    try {
        const student = await Student.findByIdAndDelete(req.params.id);
        if (!student) {
            return res.status(404).send("Student not found");
        }
        res.redirect("/students");
    } catch (e) {
        res.status(500).send("Error deleting student");
    }
});

app.listen(port, () => {
    console.log(`App is listening at http://localhost:${port}`);
});
